import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import Razorpay from 'razorpay';
import 'dotenv/config';
import admin from 'firebase-admin';

// Initialize firebase admin
if (!admin.apps.length) {
  try {
    if (process.env.FIREBASE_SERVICE_ACCOUNT_KEY) {
      admin.initializeApp({
        credential: admin.credential.cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_KEY))
      });
    } else {
      // Fallback: try application default credentials
      admin.initializeApp();
    }
  } catch (err) {
    console.warn("Firebase Admin Initialization Warning:", err);
  }
}

const db = admin.apps.length ? admin.firestore() : null;

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API routes FIRST
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok' });
  });

  // --- New Routes ---
  app.post('/api/register', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not initialized on server' });
    try {
      const data = { ...req.body, createdAt: admin.firestore.FieldValue.serverTimestamp() };
      const docRef = await db.collection('registrations').add(data);
      res.json({ id: docRef.id, message: 'Student registered successfully' });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Failed to register student' });
    }
  });

  app.get('/api/students', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not initialized on server' });
    try {
      const snapshot = await db.collection('registrations').orderBy('createdAt', 'desc').get();
      const students = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      res.json(students);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Failed to fetch students' });
    }
  });

  app.post('/api/payment', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not initialized on server' });
    try {
      const data = { ...req.body, createdAt: admin.firestore.FieldValue.serverTimestamp() };
      const docRef = await db.collection('payments').add(data);
      res.json({ id: docRef.id, message: 'Payment saved successfully' });
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Failed to save payment' });
    }
  });

  app.get('/api/payments', async (req, res) => {
    if (!db) return res.status(500).json({ error: 'Database not initialized on server' });
    try {
      const snapshot = await db.collection('payments').orderBy('createdAt', 'desc').get();
      const payments = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      res.json(payments);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Failed to fetch payments' });
    }
  });

  app.post('/api/create-order', async (req, res) => {
    try {
      if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) {
        return res.status(500).json({ error: 'Razorpay keys are missing' });
      }

      const instance = new Razorpay({
        key_id: process.env.RAZORPAY_KEY_ID,
        key_secret: process.env.RAZORPAY_KEY_SECRET,
      });

      const options = {
        amount: req.body.amount * 100, // amount in smallest currency unit
        currency: 'INR',
        receipt: `receipt_${Date.now()}`,
      };

      const order = await instance.orders.create(options);
      res.json(order);
    } catch (error) {
      console.error(error);
      res.status(500).json({ error: 'Failed to create order' });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
