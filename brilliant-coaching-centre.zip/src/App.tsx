/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from '@/src/components/Navbar';
import Hero from '@/src/components/Hero';
import About from '@/src/components/About';
import Courses from '@/src/components/Courses';
import Testimonials from '@/src/components/Testimonials';
import Contact from '@/src/components/Contact';
import Footer from '@/src/components/Footer';
import AdminLogin from '@/src/components/admin/AdminLogin';
import AdminDashboard from '@/src/components/admin/AdminDashboard';

function LandingPage() {
  return (
    <div className="selection:bg-brand-purple/30 selection:text-brand-purple-900 overflow-x-hidden">
      <Navbar />
      <main>
        <Hero />
        <About />
        <Courses />
        <Testimonials />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/admin/login" element={<AdminLogin />} />
        <Route path="/admin/dashboard" element={<AdminDashboard />} />
        <Route path="/admin" element={<AdminLogin />} />
      </Routes>
    </Router>
  );
}

