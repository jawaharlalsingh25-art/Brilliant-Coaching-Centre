import { BookOpen, Instagram, Facebook, Twitter, Youtube } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="pt-24 pb-12 px-6 border-t border-white/5 relative bg-black/20">
      <div className="max-w-7xl mx-auto">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="space-y-6">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-indigo-500 rounded-lg flex items-center justify-center text-white shadow-lg shadow-indigo-500/30 font-bold">
                B
              </div>
              <span className="text-xl font-bold tracking-tight italic">
                Brilliant<span className="text-indigo-400">Coaching Centre</span>
              </span>
            </div>
            <p className="text-white/50 max-w-xs leading-relaxed text-sm">
              Empowering students through specialized board preparation and 
              conceptual learning techniques.
            </p>
            <div className="flex items-center gap-4">
              {[Instagram, Facebook, Twitter, Youtube].map((Icon, i) => (
                <a key={i} href="#" className="w-10 h-10 rounded-full bg-white/5 border border-white/5 flex items-center justify-center text-white/40 hover:bg-indigo-600 hover:text-white transition-all">
                  <Icon size={18} />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-bold text-lg mb-6 text-white">Quick Links</h4>
            <ul className="space-y-4">
              <li><a href="#about" className="text-white/40 hover:text-indigo-300 transition-colors text-sm">About Quality</a></li>
              <li><a href="#courses" className="text-white/40 hover:text-indigo-300 transition-colors text-sm">Courses Offered</a></li>
              <li><a href="#testimonials" className="text-white/40 hover:text-indigo-300 transition-colors text-sm">Success Stories</a></li>
              <li><a href="#contact" className="text-white/40 hover:text-indigo-300 transition-colors text-sm">Admission Form</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-lg mb-6 text-white">Course Grades</h4>
            <ul className="space-y-4">
              {['Class 6', 'Class 7', 'Class 8', 'Class 9', 'Class 10'].map((item) => (
                <li key={item} className="text-white/40 hover:text-indigo-300 cursor-pointer transition-colors text-sm">
                  Board Prep for {item}
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-lg mb-6 text-white font-serif italic uppercase">Our Newsletter</h4>
            <p className="text-white/40 mb-6 text-[10px] uppercase tracking-widest font-bold">Join our academic list</p>
            <div className="relative">
              <input 
                type="email" 
                placeholder="email@example.com" 
                className="w-full bg-white/5 border border-white/10 rounded-xl px-5 py-4 text-sm focus:ring-2 focus:ring-indigo-500/20 outline-none text-white"
              />
              <button className="absolute right-2 top-2 bottom-2 bg-indigo-600 text-white px-4 rounded-lg text-xs font-bold hover:bg-indigo-500 transition-colors">
                Join
              </button>
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-white/20 text-xs italic">
            © 2026 Brilliant Coaching Centre. All Rights Reserved.
          </p>
          <div className="flex gap-8">
            <a href="#" className="text-[10px] text-white/20 hover:underline uppercase tracking-widest">Privacy Policy</a>
            <a href="#" className="text-[10px] text-white/20 hover:underline uppercase tracking-widest">Terms</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
