import { motion } from 'motion/react';
import { Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Mohan Kumar',
    role: 'Class 10 Student',
    text: 'Brilliant Coaching changed my perspective on Mathematics. The teachers explain everything so clearly!',
    rating: 5,
  },
  {
    name: 'Sunita Verma',
    role: 'Parent',
    text: 'I saw a significant improvement in my sons grade within just 3 months. Highly recommended!',
    rating: 5,
  },
  {
    name: 'Anjali Gupta',
    role: 'Class 8 Student',
    text: 'The doubt-clearing sessions are a lifesaver. I no longer fear Science exams.',
    rating: 5,
  },
];

export default function Testimonials() {
  return (
    <section id="testimonials" className="py-24 px-6 relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-brand-purple/5 blur-[120px] rounded-full opacity-30" />

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold text-indigo-300 uppercase tracking-[0.2em] mb-4 text-center">Success Stories</h2>
          <h3 className="text-4xl md:text-5xl font-extrabold mb-6">What Our <span className="text-indigo-400">Students</span> Say</h3>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((item, i) => (
            <motion.div
              key={i}
              whileInView={{ opacity: 1, y: 0 }}
              initial={{ opacity: 0, y: 30 }}
              transition={{ delay: i * 0.1 }}
              viewport={{ once: true }}
              className="glass p-10 rounded-[2.5rem] flex flex-col border-white/5"
            >
              <div className="text-indigo-400 mb-6">
                <Quote size={40} fill="currentColor" fillOpacity={0.2} />
              </div>
              <p className="text-white/70 italic mb-8 leading-relaxed">"{item.text}"</p>
              <div className="mt-auto flex items-center gap-4">
                <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center font-bold text-xl text-indigo-400 border border-white/10">
                  {item.name[0]}
                </div>
                <div>
                  <h4 className="font-bold text-lg leading-none mb-1 text-white">{item.name}</h4>
                  <p className="text-white/40 text-[10px] font-bold uppercase tracking-widest">{item.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
