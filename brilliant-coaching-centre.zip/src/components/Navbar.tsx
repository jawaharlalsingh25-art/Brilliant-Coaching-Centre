import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import RegistrationForm from './RegistrationForm';
import PaymentForm from './PaymentForm';

const navLinks = [
  { name: 'Home', href: '#' },
  { name: 'About', href: '#about' },
  { name: 'Courses', href: '#courses' },
  { name: 'Results', href: '#testimonials' },
];

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [isRegOpen, setIsRegOpen] = useState(false);
  const [isPayOpen, setIsPayOpen] = useState(false);

  return (
    <>
      <header className="flex justify-between items-center mb-8 relative z-10 p-6 md:p-8 max-w-7xl mx-auto">
        <div className="flex items-center gap-2 group cursor-pointer">
          <div className="w-10 h-10 bg-indigo-500 rounded-lg flex items-center justify-center text-white shadow-lg shadow-indigo-500/30 font-bold">
            B
          </div>
          <span className="text-xl font-bold tracking-tight italic">
            Brilliant<span className="text-indigo-400">Coaching Centre</span>
          </span>
        </div>

        {/* Desktop Links */}
        <nav className="hidden md:flex gap-6 text-sm font-medium text-white/80 items-center">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="hover:text-white transition-colors"
            >
              {link.name}
            </a>
          ))}
          <button 
            onClick={() => setIsPayOpen(true)}
            className="text-white hover:text-indigo-300 font-bold px-4 py-2 transition-colors border border-white/20 rounded-xl"
          >
            Pay Fees
          </button>
          <button 
            onClick={() => setIsRegOpen(true)}
            className="bg-indigo-600 text-white px-6 py-2.5 rounded-xl text-sm font-bold shadow-md shadow-indigo-900/40 hover:bg-indigo-500 hover:scale-105 active:scale-95 transition-all ml-4"
          >
            Join Now
          </button>
        </nav>

        {/* Mobile Toggle */}
        <button
          className="md:hidden text-white p-2"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <X size={24} /> : <Menu size={24} />}
        </button>
      </header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="absolute top-20 left-4 right-4 glass border border-white/10 rounded-2xl md:hidden overflow-hidden z-50 bg-indigo-950/90"
          >
            <div className="flex flex-col p-6 gap-4">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={() => setIsOpen(false)}
                  className="text-lg font-medium text-white/80 hover:text-white"
                >
                  {link.name}
                </a>
              ))}
              <button 
                onClick={() => { setIsOpen(false); setIsPayOpen(true); }}
                className="bg-white/10 border border-white/20 text-white w-full py-4 rounded-xl font-bold text-lg hover:bg-white/20"
              >
                Pay Fees
              </button>
              <button 
                onClick={() => { setIsOpen(false); setIsRegOpen(true); }}
                className="bg-indigo-600 text-white w-full py-4 rounded-xl font-bold text-lg shadow-lg hover:bg-indigo-500"
              >
                Join Now
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isRegOpen && <RegistrationForm onClose={() => setIsRegOpen(false)} />}
      </AnimatePresence>
      <AnimatePresence>
        {isPayOpen && <PaymentForm onClose={() => setIsPayOpen(false)} />}
      </AnimatePresence>
    </>
  );
}
