import { motion } from 'motion/react';
import { ChevronRight, Sparkles } from 'lucide-react';

const courses = [
  { class: 'Class 6', focus: 'Foundation & Logic Building' },
  { class: 'Class 7', focus: 'Conceptual Strengthening' },
  { class: 'Class 8', focus: 'Pre-Board Preparation' },
  { class: 'Class 9', focus: 'Bridge to Secondary School' },
  { class: 'Class 10', focus: 'Ultimate Board Achievement' },
];

export default function Courses() {
  return (
    <section id="courses" className="py-24 px-6 relative">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-sm font-bold text-indigo-300 uppercase tracking-[0.2em] mb-4">Our Programs</h2>
          <h3 className="text-4xl md:text-5xl font-extrabold mb-6">Explore Our <span className="text-gradient">Courses</span></h3>
          <p className="text-white/50 max-w-2xl mx-auto text-lg leading-relaxed">
            Tailored curriculum for every grade level, ensuring complex topics 
            are broken down into digestible parts.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-6">
          {courses.map((course, i) => (
            <motion.div
              key={i}
              whileInView={{ opacity: 1, scale: 1 }}
              initial={{ opacity: 0, scale: 0.9 }}
              transition={{ delay: i * 0.1 }}
              viewport={{ once: true }}
              className="glass p-8 rounded-[2rem] flex flex-col items-center text-center group hover:bg-white/10 hover:border-indigo-500/50 transition-all cursor-default"
            >
              <div className="w-16 h-16 bg-white/5 text-indigo-400 rounded-3xl flex items-center justify-center mb-6 group-hover:scale-110 group-hover:bg-indigo-600 group-hover:text-white transition-all">
                <Sparkles size={28} />
              </div>
              <h4 className="text-2xl font-black mb-3 text-white">{course.class}</h4>
              <p className="text-white/40 text-sm mb-8 leading-tight">{course.focus}</p>
              <button className="mt-auto flex items-center gap-2 text-indigo-400 font-bold text-sm hover:text-white transition-colors">
                View Details <ChevronRight size={16} />
              </button>
            </motion.div>
          ))}
        </div>

        <div className="mt-16 glass p-8 md:p-12 rounded-[3rem] bg-linear-to-r from-indigo-900/40 via-indigo-600/40 to-purple-800/40 border-white/5 text-white flex flex-col md:flex-row items-center justify-between gap-8 md:text-left text-center">
          <div>
            <h4 className="text-2xl md:text-3xl font-bold mb-2">Not sure where to start?</h4>
            <p className="text-white/60 max-w-md">Schedule a free counseling session with our academic experts today.</p>
          </div>
          <button className="bg-indigo-600 text-white px-10 py-5 rounded-xl font-bold text-lg hover:bg-indigo-500 transition-all shadow-xl shadow-indigo-900/40 active:scale-95">
            Book Free Demo
          </button>
        </div>
      </div>
    </section>
  );
}
