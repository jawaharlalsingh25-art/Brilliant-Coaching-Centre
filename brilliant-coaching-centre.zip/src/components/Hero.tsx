import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { GraduationCap, ArrowRight, Star } from 'lucide-react';
import RegistrationForm from './RegistrationForm';

export default function Hero() {
  const [isRegOpen, setIsRegOpen] = useState(false);

  return (
    <section className="relative min-h-[90vh] flex items-center pt-24 overflow-hidden">
      {/* Background Orbs */}
      <div className="absolute top-[-10%] right-[-5%] w-[400px] h-[400px] bg-purple-500/20 rounded-full blur-3xl opacity-50" />
      <div className="absolute bottom-[-10%] left-[-5%] w-[300px] h-[300px] bg-indigo-500/20 rounded-full blur-3xl opacity-50" />

      <div className="max-w-7xl mx-auto px-6 w-full grid lg:grid-cols-2 gap-12 items-center">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="inline-block px-3 py-1 bg-white/10 border border-white/20 rounded-full text-xs font-semibold text-indigo-300 mb-6">
            ✨ ADMISSIONS OPEN FOR 2026-2027
          </div>
          
          <h1 className="text-5xl md:text-7xl font-extrabold leading-[1.1] mb-6 tracking-tight">
            Best Coaching for <br />
            <span className="text-gradient">Class 6–10 Board</span> <br />
            Preparation
          </h1>
          
          <p className="text-white/70 text-lg md:text-xl mb-10 max-w-lg leading-relaxed">
            Expert faculty, personalized study plans, and interactive learning modules 
            designed to build a solid foundation and ace board exams.
          </p>

          <div className="flex flex-col sm:flex-row gap-4">
            <button 
              onClick={() => setIsRegOpen(true)}
              className="px-8 py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold shadow-xl shadow-indigo-900/40 transition-all flex items-center justify-center gap-2 group active:scale-95"
            >
              Register Now
              <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
            </button>
            <button className="px-8 py-4 bg-white/10 border border-white/20 hover:bg-white/20 text-white rounded-xl font-bold backdrop-blur-md transition-all active:scale-95">
              Pay Fees Online
            </button>
          </div>

          <div className="mt-12 flex gap-12 items-center border-t border-white/10 pt-8">
            <div className="space-y-1">
              <div className="text-2xl font-bold">10+</div>
              <div className="text-[10px] text-white/50 uppercase tracking-widest font-bold">Years Excellence</div>
            </div>
            <div className="space-y-1">
              <div className="text-2xl font-bold">2000+</div>
              <div className="text-[10px] text-white/50 uppercase tracking-widest font-bold">Students Topped</div>
            </div>
            <div className="space-y-1">
              <div className="text-2xl font-bold">100%</div>
              <div className="text-[10px] text-white/50 uppercase tracking-widest font-bold">Syllabus Mastery</div>
            </div>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="relative"
        >
          <div className="relative z-10 glass p-3 rounded-[2rem] hover:scale-[1.02] transition-transform duration-500">
            <img 
              src="https://images.unsplash.com/photo-1523240795612-9a054b0db644?q=80&w=800&auto=format&fit=crop" 
              alt="Students Studying" 
              className="rounded-[1.5rem] w-full aspect-video lg:aspect-square object-cover shadow-inner opacity-90"
              referrerPolicy="no-referrer"
            />
            {/* Floating Card */}
            <motion.div 
              animate={{ y: [0, -15, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -bottom-6 -left-6 bg-indigo-600/90 backdrop-blur-md p-6 rounded-2xl shadow-2xl flex items-center gap-4 border border-white/20"
            >
              <div className="w-12 h-12 bg-white/20 text-white rounded-full flex items-center justify-center">
                <GraduationCap size={24} />
              </div>
              <div>
                <p className="text-[10px] text-white/60 font-bold uppercase tracking-wider">Results</p>
                <p className="text-xl font-black text-white">95% Pass Rate</p>
              </div>
            </motion.div>
          </div>

          {/* Decorative Elements */}
          <div className="absolute -top-10 -right-10 w-32 h-32 bg-brand-purple/20 rounded-full blur-2xl" />
          <div className="absolute top-1/2 -left-20 w-40 h-40 bg-brand-indigo/20 rounded-full blur-3xl opacity-30" />
        </motion.div>
      </div>

      <AnimatePresence>
        {isRegOpen && <RegistrationForm onClose={() => setIsRegOpen(false)} />}
      </AnimatePresence>
    </section>
  );
}
