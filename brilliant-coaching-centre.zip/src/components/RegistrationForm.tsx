import { useState, ChangeEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useForm } from 'react-hook-form';
import { Upload, X, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import { collection, doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { db, auth } from '../lib/firebase';
import { handleFirestoreError, OperationType } from '../lib/firestore_errors';

type FormData = {
  studentName: string;
  parentName: string;
  phoneNumber: string;
  email: string;
  address: string;
  studentClass: string;
  schoolName: string;
};

export default function RegistrationForm({ onClose }: { onClose: () => void }) {
  const { register, handleSubmit, formState: { errors, isSubmitting }, reset } = useForm<FormData>();
  const [photoData, setPhotoData] = useState<string>('');
  const [success, setSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handlePhotoUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 400 * 1024) {
        setErrorMsg('Photo must be less than 400KB');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotoData(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const onSubmit = async (data: FormData) => {
    setErrorMsg('');
    try {
      if (!auth.currentUser) {
        const provider = new GoogleAuthProvider();
        await signInWithPopup(auth, provider);
      }
      
      const user = auth.currentUser;
      if (!user) throw new Error("Could not log in");

      const payload: any = {
        studentName: data.studentName,
        parentName: data.parentName,
        phoneNumber: data.phoneNumber,
        email: data.email,
        address: data.address,
        studentClass: data.studentClass,
        schoolName: data.schoolName,
        userId: user.uid,
      };
      
      if (photoData) {
        payload.photoData = photoData;
      }

      const res = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const resData = await res.json();
      if (!res.ok) throw new Error(resData.error || 'Failed to register');

      setSuccess(true);
      reset();
      setPhotoData('');
      setTimeout(() => {
        onClose();
      }, 3000);
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'An error occurred during registration.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        exit={{ opacity: 0 }}
        className="absolute inset-0 bg-black/60 backdrop-blur-sm" 
        onClick={onClose} 
      />
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 20 }} 
        animate={{ opacity: 1, scale: 1, y: 0 }} 
        exit={{ opacity: 0, scale: 0.9, y: 20 }}
        className="relative z-10 w-full max-w-2xl max-h-[90vh] overflow-y-auto glass p-8 rounded-[2rem] bg-indigo-950 border border-white/20 shadow-2xl"
      >
        <button onClick={onClose} className="absolute top-6 right-6 text-white/50 hover:text-white transition-colors">
          <X size={24} />
        </button>

        <h2 className="text-2xl font-extrabold mb-6 text-white tracking-tight">Student Registration</h2>
        
        {success ? (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center justify-center py-12 text-center"
          >
            <div className="w-20 h-20 bg-green-500/20 text-green-400 rounded-full flex items-center justify-center mb-6">
              <CheckCircle size={40} />
            </div>
            <h3 className="text-2xl font-bold text-white mb-2">Registration Successful!</h3>
            <p className="text-white/60">We have received your application. Our team will contact you shortly.</p>
          </motion.div>
        ) : (
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            {errorMsg && (
              <div className="flex items-center gap-3 p-4 rounded-xl bg-red-500/10 text-red-400 border border-red-500/20">
                <AlertCircle size={20} />
                <p className="text-sm font-medium">{errorMsg}</p>
              </div>
            )}

            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-indigo-300 ml-2">Student Name *</label>
                <input 
                  {...register('studentName', { required: 'Student name is required' })}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500/50 transition-colors" 
                  placeholder="John Doe" 
                />
                {errors.studentName && <span className="text-red-400 text-xs ml-2">{errors.studentName.message}</span>}
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-indigo-300 ml-2">Parent Name *</label>
                <input 
                  {...register('parentName', { required: 'Parent name is required' })}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500/50 transition-colors" 
                  placeholder="Jane Doe" 
                />
                {errors.parentName && <span className="text-red-400 text-xs ml-2">{errors.parentName.message}</span>}
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-indigo-300 ml-2">Phone Number *</label>
                <input 
                  {...register('phoneNumber', { 
                    required: 'Phone number is required',
                    pattern: { value: /^[0-9+\-\\s()]{10,15}$/, message: 'Invalid phone number format' }
                  })}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500/50 transition-colors" 
                  placeholder="8709965550, 9297502547" 
                />
                {errors.phoneNumber && <span className="text-red-400 text-xs ml-2">{errors.phoneNumber.message}</span>}
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-indigo-300 ml-2">Email *</label>
                <input 
                  {...register('email', { 
                    required: 'Email is required',
                    pattern: { value: /^\\S+@\\S+\\.\\S+$/, message: 'Invalid email address' }
                  })}
                  type="email"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500/50 transition-colors" 
                  placeholder="john@example.com" 
                />
                {errors.email && <span className="text-red-400 text-xs ml-2">{errors.email.message}</span>}
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-indigo-300 ml-2">Class *</label>
                <select 
                  {...register('studentClass', { required: 'Class is required' })}
                  className="w-full bg-[#1e1b4b] border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500/50 transition-colors"
                >
                  <option value="">Select Class</option>
                  <option value="Class 6">Class 6</option>
                  <option value="Class 7">Class 7</option>
                  <option value="Class 8">Class 8</option>
                  <option value="Class 9">Class 9</option>
                  <option value="Class 10">Class 10</option>
                </select>
                {errors.studentClass && <span className="text-red-400 text-xs ml-2">{errors.studentClass.message}</span>}
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-indigo-300 ml-2">School Name *</label>
                <input 
                  {...register('schoolName', { required: 'School name is required' })}
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500/50 transition-colors" 
                  placeholder="Greenwood High School" 
                />
                {errors.schoolName && <span className="text-red-400 text-xs ml-2">{errors.schoolName.message}</span>}
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-bold uppercase tracking-widest text-indigo-300 ml-2">Address *</label>
              <textarea 
                {...register('address', { required: 'Address is required' })}
                rows={2}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500/50 transition-colors resize-y" 
                placeholder="Full Address" 
              />
              {errors.address && <span className="text-red-400 text-xs ml-2">{errors.address.message}</span>}
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-bold uppercase tracking-widest text-indigo-300 ml-2">Upload Photo (Max 400KB)</label>
              <div className="flex items-center gap-4">
                <label className="flex items-center gap-2 px-4 py-3 bg-white/5 border border-white/10 hover:bg-white/10 text-white rounded-xl cursor-pointer transition-colors text-sm font-medium">
                  <Upload size={18} />
                  Choose File
                  <input type="file" accept="image/*" onChange={handlePhotoUpload} className="hidden" />
                </label>
                {photoData && (
                  <div className="relative w-12 h-12 rounded-lg overflow-hidden border border-white/20">
                    <img src={photoData} alt="Preview" className="w-full h-full object-cover" />
                  </div>
                )}
              </div>
            </div>

            <button 
              type="submit" 
              disabled={isSubmitting}
              className="w-full py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold shadow-xl shadow-indigo-900/40 active:scale-95 transition-all flex items-center justify-center gap-2"
            >
              {isSubmitting ? <Loader2 size={20} className="animate-spin" /> : 'Submit Registration'}
            </button>
            
            <p className="text-[10px] text-white/40 text-center mt-4 uppercase tracking-widest">
              You will be prompted to log in with Google before submission.
            </p>
          </form>
        )}
      </motion.div>
    </div>
  );
}
