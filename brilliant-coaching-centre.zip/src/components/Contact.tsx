import { motion } from 'motion/react';
import { Mail, Phone, MapPin, Send } from 'lucide-react';

export default function Contact() {
  return (
    <section id="contact" className="py-24 px-6 relative">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-16">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
          >
            <h2 className="text-sm font-bold text-indigo-300 uppercase tracking-[0.2em] mb-4">Get In Touch</h2>
            <h3 className="text-4xl md:text-5xl font-extrabold mb-8 leading-tight">
              Ready to Start Your <br />
              <span className="text-gradient">Academic Journey?</span>
            </h3>
            
            <div className="space-y-8 mt-12">
              <div className="flex items-center gap-6">
                <div className="w-14 h-14 bg-indigo-500/10 text-indigo-400 rounded-2xl flex items-center justify-center border border-indigo-500/10">
                  <Phone size={24} />
                </div>
                <div>
                  <p className="text-white/40 text-[10px] font-bold uppercase tracking-widest mb-1">Call Us</p>
                  <p className="text-xl font-bold text-white">8709965550, 9297502547</p>
                </div>
              </div>
              
              <div className="flex items-center gap-6">
                <div className="w-14 h-14 bg-purple-500/10 text-purple-400 rounded-2xl flex items-center justify-center border border-purple-500/10">
                  <Mail size={24} />
                </div>
                <div>
                  <p className="text-white/40 text-[10px] font-bold uppercase tracking-widest mb-1">Email Us</p>
                  <p className="text-xl font-bold text-white">hello@brilliantcoaching.com</p>
                </div>
              </div>

              <div className="flex items-center gap-6">
                <div className="w-14 h-14 bg-white/5 text-slate-300 rounded-2xl flex items-center justify-center border border-white/5">
                  <MapPin size={24} />
                </div>
                <div>
                  <p className="text-white/40 text-[10px] font-bold uppercase tracking-widest mb-1">Visit Us</p>
                  <p className="text-xl font-bold text-white">NEW AREA SANJHAULI(ROHTAS), IN FRONT OF STATION ROAD</p>
                </div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="glass p-8 md:p-12 rounded-[3rem]"
          >
            <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-indigo-300 ml-2">Student Name</label>
                  <input type="text" placeholder="John Doe" className="w-full bg-white/5 border border-white/10 rounded-xl px-6 py-4 text-white outline-none focus:border-indigo-500/50 transition-colors" />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-indigo-300 ml-2">Class</label>
                  <select className="w-full bg-white/5 border border-white/10 rounded-xl px-6 py-4 text-white outline-none focus:border-indigo-500/50 transition-colors appearance-none">
                    <option className="bg-slate-900">Class 6</option>
                    <option className="bg-slate-900">Class 7</option>
                    <option className="bg-slate-900">Class 8</option>
                    <option className="bg-slate-900">Class 9</option>
                    <option className="bg-slate-900">Class 10</option>
                  </select>
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-indigo-300 ml-2">Phone Number</label>
                <input type="tel" placeholder="10-digit mobile number" className="w-full bg-white/5 border border-white/10 rounded-xl px-6 py-4 text-white outline-none focus:border-indigo-500/50 transition-colors" />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold uppercase tracking-widest text-indigo-300 ml-2">Message (Optional)</label>
                <textarea rows={4} placeholder="Your queries..." className="w-full bg-white/5 border border-white/10 rounded-xl px-6 py-4 text-white outline-none focus:border-indigo-500/50 transition-colors resize-none"></textarea>
              </div>
              <button className="bg-indigo-600 text-white w-full py-5 rounded-xl font-extrabold text-lg shadow-xl shadow-indigo-900/40 hover:bg-indigo-500 active:scale-[0.98] transition-all flex items-center justify-center gap-3">
                Send Application <Send size={20} />
              </button>
            </form>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
