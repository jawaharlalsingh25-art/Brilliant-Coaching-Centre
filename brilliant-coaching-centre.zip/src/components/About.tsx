import { motion } from 'motion/react';
import { Users, BookCheck, Clock, Award } from 'lucide-react';

const stats = [
  { icon: Users, label: 'Students Taught', value: '3,000+' },
  { icon: Award, label: 'Success Rate', value: '98%' },
  { icon: BookCheck, label: 'Mock Tests', value: '120+' },
  { icon: Clock, label: 'Doubt Classes', value: '24/7' },
];

const features = [
  {
    title: 'Expert Faculty',
    description: 'Learn from highly qualified teachers with over 15 years of board exam expertise.',
  },
  {
    title: 'Individual Attention',
    description: 'We maintain small batch sizes to ensure every student gets the focus they deserve.',
  },
  {
    title: 'Modern Teaching',
    description: 'Using interactive visual aids and digital resources to make complex concepts simple.',
  },
];

export default function About() {
  return (
    <section id="about" className="py-24 px-6 relative">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col lg:flex-row gap-16 items-center">
          <div className="lg:w-1/2">
            <h2 className="text-sm font-bold text-indigo-300 uppercase tracking-[0.2em] mb-4">Why Choose Us</h2>
            <h3 className="text-4xl md:text-5xl font-extrabold mb-8 leading-tight">
              A Legacy of <br /><span className="text-gradient">Teaching Quality</span>
            </h3>
            
            <p className="text-white/60 text-lg mb-10 leading-relaxed max-w-xl">
              At Brilliant Coaching Centre, we believe that every student has the potential to excel. 
              Our structured curriculum and dedicated faculty transform hard work into success.
            </p>

            <div className="space-y-6 mb-12">
              {features.map((feature, i) => (
                <div key={i} className="flex gap-4 p-5 rounded-2xl bg-white/5 border border-white/5 hover:border-indigo-500/30 hover:bg-white/10 transition-all duration-300 group">
                  <div className="w-1.5 h-auto bg-indigo-500 rounded-full group-hover:scale-y-110 transition-transform" />
                  <div>
                    <h4 className="font-bold text-lg mb-1 text-white">{feature.title}</h4>
                    <p className="text-white/50 text-sm leading-relaxed">{feature.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="lg:w-1/2 grid grid-cols-2 gap-4">
            {stats.map((stat, i) => (
              <motion.div
                key={i}
                whileInView={{ opacity: 1, y: 0 }}
                initial={{ opacity: 0, y: 20 }}
                transition={{ delay: i * 0.1 }}
                viewport={{ once: true }}
                className="glass p-8 rounded-3xl flex flex-col items-center text-center group hover:border-indigo-500/50 transition-all"
              >
                <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center text-indigo-400 mb-4 group-hover:bg-indigo-600 group-hover:text-white transition-colors">
                  <stat.icon size={24} />
                </div>
                <p className="text-3xl font-black mb-1">{stat.value}</p>
                <p className="text-white/40 text-[10px] font-bold uppercase tracking-widest">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
