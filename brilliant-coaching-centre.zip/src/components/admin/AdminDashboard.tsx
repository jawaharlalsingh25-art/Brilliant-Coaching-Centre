import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Users, CreditCard, Search, Download, Trash2, LogOut, Loader2 } from 'lucide-react';
import { collection, onSnapshot, query, orderBy, deleteDoc, doc } from 'firebase/firestore';
import { auth, db } from '../../lib/firebase';
import { signOut } from 'firebase/auth';
import { useNavigate } from 'react-router-dom';
import { handleFirestoreError, OperationType } from '../../lib/firestore_errors';

export default function AdminDashboard() {
  const [registrations, setRegistrations] = useState<any[]>([]);
  const [payments, setPayments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [activeTab, setActiveTab] = useState<'students' | 'payments'>('students');
  const navigate = useNavigate();

  useEffect(() => {
    // Ensure user is signed in
    const unsubscribeAuth = auth.onAuthStateChanged(user => {
      if (!user) {
        navigate('/admin/login');
      }
    });

    return () => unsubscribeAuth();
  }, [navigate]);

  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true);
        const regRes = await fetch('/api/students');
        if (regRes.ok) {
          const regData = await regRes.json();
          setRegistrations(regData);
        }
        
        const payRes = await fetch('/api/payments');
        if (payRes.ok) {
          const payData = await payRes.json();
          setPayments(payData);
        }
      } catch (err) {
        console.error('Failed to load data from APIs', err);
      } finally {
        setLoading(false);
      }
    };
    
    loadData();
    // Poll every 10 seconds to keep it pseudo-realtime
    const intervalId = setInterval(loadData, 10000);
    return () => clearInterval(intervalId);
  }, []);

  const handleLogout = async () => {
    await signOut(auth);
    navigate('/admin/login');
  };

  const handleDelete = async (collectionName: string, id: string) => {
    if (!window.confirm('Are you sure you want to delete this record?')) return;
    try {
      await deleteDoc(doc(db, collectionName, id));
    } catch (error) {
      handleFirestoreError(error, OperationType.DELETE, `${collectionName}/${id}`);
      alert('Failed to delete record.');
    }
  };

  const downloadCSV = () => {
    let csvContent = "data:text/csv;charset=utf-8,";
    
    if (activeTab === 'students') {
      const headers = ["Name", "Class", "School", "Parent", "Phone", "Email", "Date"];
      csvContent += headers.join(",") + "\n";
      registrations.forEach(row => {
        const date = row.createdAt ? (row.createdAt._seconds ? new Date(row.createdAt._seconds * 1000).toLocaleDateString() : new Date(row.createdAt).toLocaleDateString()) : 'N/A';
        const rowData = [
          `"${row.studentName}"`,
          `"${row.studentClass}"`,
          `"${row.schoolName}"`,
          `"${row.parentName}"`,
          `"${row.phoneNumber}"`,
          `"${row.email}"`,
          date
        ];
        csvContent += rowData.join(",") + "\n";
      });
    } else {
      const headers = ["Student Name", "Amount", "Payment ID", "Date"];
      csvContent += headers.join(",") + "\n";
      payments.forEach(row => {
        const date = row.createdAt ? (row.createdAt._seconds ? new Date(row.createdAt._seconds * 1000).toLocaleDateString() : new Date(row.createdAt).toLocaleDateString()) : 'N/A';
        const rowData = [
          `"${row.studentName}"`,
          row.amount,
          `"${row.paymentId}"`,
          date
        ];
        csvContent += rowData.join(",") + "\n";
      });
    }

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `${activeTab}_data.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const filteredRegistrations = registrations.filter(r => 
    r.studentName?.toLowerCase().includes(search.toLowerCase()) || 
    r.phoneNumber?.includes(search) ||
    r.email?.toLowerCase().includes(search.toLowerCase())
  );

  const filteredPayments = payments.filter(p =>
    p.studentName?.toLowerCase().includes(search.toLowerCase()) ||
    p.paymentId?.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) {
    return (
      <div className="min-h-screen bg-indigo-950 flex items-center justify-center">
        <Loader2 className="animate-spin text-indigo-500" size={48} />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-indigo-950 text-white flex flex-col md:flex-row">
      {/* Sidebar */}
      <div className="w-full md:w-64 bg-black/30 border-r border-white/5 p-6 flex flex-col">
        <div className="flex items-center gap-3 mb-10">
          <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center font-bold">B</div>
          <span className="font-bold tracking-widest text-sm uppercase">Admin Panel</span>
        </div>

        <nav className="flex-1 space-y-2">
          <button 
            onClick={() => setActiveTab('students')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'students' ? 'bg-indigo-600 text-white' : 'text-white/60 hover:bg-white/5 hover:text-white'}`}
          >
            <Users size={18} />
            <span className="font-medium text-sm">Students</span>
          </button>
          <button 
            onClick={() => setActiveTab('payments')}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${activeTab === 'payments' ? 'bg-indigo-600 text-white' : 'text-white/60 hover:bg-white/5 hover:text-white'}`}
          >
            <CreditCard size={18} />
            <span className="font-medium text-sm">Payments</span>
          </button>
        </nav>

        <button 
          onClick={handleLogout}
          className="mt-auto flex items-center gap-3 px-4 py-3 text-red-400 hover:bg-red-500/10 rounded-xl transition-colors"
        >
          <LogOut size={18} />
          <span className="font-medium text-sm">Sign Out</span>
        </button>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-8 overflow-y-auto h-screen bg-gradient-to-br from-indigo-950 10% to-[#1e1b4b] 90%">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-8">
          <div>
            <h1 className="text-3xl font-extrabold tracking-tight">
              {activeTab === 'students' ? 'Registered Students' : 'Payment Records'}
            </h1>
            <p className="text-white/50 text-sm mt-1">
              Manage your {activeTab} data and export reports.
            </p>
          </div>

          <div className="flex items-center gap-4">
            <div className="relative">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-white/40" />
              <input 
                type="text" 
                placeholder="Search..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="pl-10 pr-4 py-2.5 bg-black/30 border border-white/10 rounded-xl text-sm focus:border-indigo-500/50 outline-none w-full md:w-64 transition-all"
              />
            </div>
            <button 
              onClick={downloadCSV}
              className="flex items-center gap-2 px-4 py-2.5 bg-white/10 border border-white/10 hover:bg-white/20 rounded-xl text-sm font-medium transition-colors"
            >
              <Download size={16} />
              <span className="hidden sm:inline">Export CSV</span>
            </button>
          </div>
        </div>

        {/* Data Table */}
        <div className="bg-black/20 border border-white/10 rounded-2xl overflow-hidden glass">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-white/5 border-b border-white/10 text-white/60">
                {activeTab === 'students' ? (
                  <tr>
                    <th className="px-6 py-4 font-medium">Student Name</th>
                    <th className="px-6 py-4 font-medium">Class / School</th>
                    <th className="px-6 py-4 font-medium">Parent Contact</th>
                    <th className="px-6 py-4 font-medium">Date Joined</th>
                    <th className="px-6 py-4 font-medium text-right">Actions</th>
                  </tr>
                ) : (
                  <tr>
                    <th className="px-6 py-4 font-medium">Student Name</th>
                    <th className="px-6 py-4 font-medium">Amount</th>
                    <th className="px-6 py-4 font-medium">Payment ID</th>
                    <th className="px-6 py-4 font-medium">Date</th>
                    <th className="px-6 py-4 font-medium text-right">Actions</th>
                  </tr>
                )}
              </thead>
              <tbody className="divide-y divide-white/5">
                {activeTab === 'students' && filteredRegistrations.map((student) => (
                  <tr key={student.id} className="hover:bg-white/[0.02]">
                    <td className="px-6 py-4">
                      <div className="font-bold text-white">{student.studentName}</div>
                      <div className="text-white/40 text-xs">{student.email}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="text-indigo-300">{student.studentClass}</div>
                      <div className="text-white/40 text-xs truncate max-w-[200px]">{student.schoolName}</div>
                    </td>
                    <td className="px-6 py-4">
                      <div>{student.parentName}</div>
                      <div className="text-white/40 text-xs">{student.phoneNumber}</div>
                    </td>
                    <td className="px-6 py-4 text-white/60">
                      {student.createdAt ? (student.createdAt._seconds ? new Date(student.createdAt._seconds * 1000).toLocaleDateString() : new Date(student.createdAt).toLocaleDateString()) : 'N/A'}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button 
                        onClick={() => handleDelete('registrations', student.id)}
                        className="p-2 text-red-400 hover:bg-red-400/10 rounded-lg transition-colors inline-flex"
                        title="Delete Record"
                      >
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                ))}
                
                {activeTab === 'payments' && filteredPayments.map((payment) => (
                  <tr key={payment.id} className="hover:bg-white/[0.02]">
                    <td className="px-6 py-4 font-medium text-white">{payment.studentName}</td>
                    <td className="px-6 py-4 font-bold text-green-400">₹{payment.amount}</td>
                    <td className="px-6 py-4 text-white/60 font-mono text-xs">{payment.paymentId}</td>
                    <td className="px-6 py-4 text-white/60">
                      {payment.createdAt ? (payment.createdAt._seconds ? new Date(payment.createdAt._seconds * 1000).toLocaleDateString() : new Date(payment.createdAt).toLocaleDateString()) : 'N/A'}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <button 
                        onClick={() => handleDelete('payments', payment.id)}
                        className="p-2 text-red-400 hover:bg-red-400/10 rounded-lg transition-colors inline-flex"
                        title="Delete Record"
                      >
                        <Trash2 size={16} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            
            {activeTab === 'students' && filteredRegistrations.length === 0 && (
              <div className="p-12 text-center text-white/40">No students found.</div>
            )}
            {activeTab === 'payments' && filteredPayments.length === 0 && (
              <div className="p-12 text-center text-white/40">No payments found.</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
