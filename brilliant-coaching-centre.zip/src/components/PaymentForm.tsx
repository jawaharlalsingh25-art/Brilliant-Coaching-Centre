import { useState, useEffect, FormEvent } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import { collection, doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import { db, auth } from '../lib/firebase';
import { handleFirestoreError, OperationType } from '../lib/firestore_errors';

export default function PaymentForm({ onClose }: { onClose: () => void }) {
  const [isLoaded, setIsLoaded] = useState(false);
  const [studentName, setStudentName] = useState('');
  const [amount, setAmount] = useState<number | ''>('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [success, setSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    const script = document.createElement("script");
    script.src = "https://checkout.razorpay.com/v1/checkout.js";
    script.onload = () => setIsLoaded(true);
    script.onerror = () => setErrorMsg("Failed to load Razorpay SDK");
    document.body.appendChild(script);
  }, []);

  const handlePayment = async (e: FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    if (!studentName || !amount) {
      setErrorMsg('Please fill in all details');
      return;
    }
    
    // Minimum amount is Rs 1
    if (amount < 1) {
      setErrorMsg('Amount must be at least ₹1');
      return;
    }

    try {
      setIsProcessing(true);

      // Ensure user is logged in
      if (!auth.currentUser) {
        const provider = new GoogleAuthProvider();
        await signInWithPopup(auth, provider);
      }
      const user = auth.currentUser;
      if (!user) throw new Error("Could not log in");

      // 1. Create Order on Backend
      const res = await fetch('/api/create-order', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ amount })
      });

      const data = await res.json();
      
      if (!res.ok) {
        throw new Error(data.error || 'Failed to create order');
      }

      // 2. Open Razorpay Checkout
      const options = {
        key: import.meta.env.VITE_RAZORPAY_KEY_ID || 'dummy_key', // Required if we don't pass from backend, but Razorpay checkout needs it
        amount: data.amount,
        currency: data.currency,
        name: "Brilliant Coaching",
        description: "Fee Payment",
        order_id: data.id,
        handler: async function (response: any) {
          try {
            // Save to Backend
            const res = await fetch('/api/payment', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                studentName,
                amount: Number(amount),
                paymentId: response.razorpay_payment_id,
                userId: user.uid,
              })
            });
            const resData = await res.json();
            if (!res.ok) throw new Error(resData.error || 'Failed to save payment record');
            
            setSuccess(true);
            setTimeout(() => onClose(), 3000);
          } catch (err: any) {
            console.error(err);
            setErrorMsg(err.message || 'Payment successful, but failed to save record.');
          }
        },
        prefill: {
          name: studentName,
          email: user.email || ''
        },
        theme: {
          color: "#4f46e5"
        }
      };

      const rzp = new (window as any).Razorpay(options);
      rzp.on('payment.failed', function (response: any) {
        setIsProcessing(false);
        setErrorMsg(response.error.description || 'Payment failed');
      });

      rzp.open();
    } catch (err: any) {
      console.error(err);
      setErrorMsg(err.message || 'Something went wrong');
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0 }} 
        animate={{ opacity: 1 }} 
        exit={{ opacity: 0 }}
        className="absolute inset-0 bg-black/60 backdrop-blur-sm" 
        onClick={onClose} 
      />
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 20 }} 
        animate={{ opacity: 1, scale: 1, y: 0 }} 
        exit={{ opacity: 0, scale: 0.9, y: 20 }}
        className="relative z-10 w-full max-w-md bg-indigo-950 border border-white/20 glass p-8 rounded-[2rem] shadow-2xl"
      >
        <button onClick={onClose} className="absolute top-6 right-6 text-white/50 hover:text-white transition-colors disabled:opacity-50" disabled={isProcessing}>
          <X size={24} />
        </button>

        <h2 className="text-2xl font-extrabold mb-6 text-white tracking-tight">Pay Fees Online</h2>

        {success ? (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center justify-center py-6 text-center"
          >
            <div className="w-20 h-20 bg-green-500/20 text-green-400 rounded-full flex items-center justify-center mb-6">
              <CheckCircle size={40} />
            </div>
            <h3 className="text-2xl font-bold text-white mb-2">Payment Successful!</h3>
            <p className="text-white/60">Thank you. Your fee payment has been recorded.</p>
          </motion.div>
        ) : (
          <form onSubmit={handlePayment} className="space-y-6">
            {!isLoaded && (
              <div className="text-indigo-300 text-sm flex items-center gap-2 mb-4">
                <Loader2 size={16} className="animate-spin" /> Loading Payment Gateway...
              </div>
            )}
            
            {errorMsg && (
              <div className="flex items-center gap-3 p-4 rounded-xl bg-red-500/10 text-red-400 border border-red-500/20">
                <AlertCircle size={20} className="shrink-0" />
                <p className="text-sm font-medium">{errorMsg}</p>
              </div>
            )}

            <div className="space-y-2">
              <label className="text-[10px] font-bold uppercase tracking-widest text-indigo-300 ml-2">Student Name *</label>
              <input 
                type="text"
                value={studentName}
                onChange={e => setStudentName(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500/50 transition-colors" 
                placeholder="John Doe" 
                required
              />
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-bold uppercase tracking-widest text-indigo-300 ml-2">Amount (₹) *</label>
              <input 
                type="number"
                value={amount}
                onChange={e => setAmount(e.target.value === '' ? '' : Number(e.target.value))}
                min="1"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-white outline-none focus:border-indigo-500/50 transition-colors" 
                placeholder="5000" 
                required
              />
            </div>

            <button 
              type="submit" 
              disabled={!isLoaded || isProcessing}
              className="w-full py-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl font-bold shadow-xl shadow-indigo-900/40 active:scale-95 transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:active:scale-100"
            >
              {isProcessing ? <Loader2 size={20} className="animate-spin" /> : 'Pay Now'}
            </button>
            <p className="text-[10px] text-white/40 text-center mt-4">
              Secured by Razorpay
            </p>
          </form>
        )}
      </motion.div>
    </div>
  );
}
